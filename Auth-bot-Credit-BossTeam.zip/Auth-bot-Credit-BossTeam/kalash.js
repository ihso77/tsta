module.exports = {
  token: process.env.token,
  port: "3000",
  prefix: "+",
  client: "819508960587284521",
  client_id: "1369365938847350794",
  client_secret: "mY6xKJUPQqqgsTW06t5xtzJHxhGGodxY",
  redirect_uri: "https://f5c97a57-5945-4b06-bf77-d78233900787-00-1fs5de46gro5g.sisko.replit.dev/",
  footer: "Axey Auth V999",
  support: "",
  wehbook: "", //wehbook de logs
  owners: ["819508960587284521", "1091698984575324322"],
  authLink: `https://discord.com/oauth2/authorize?client_id=1369365938847350794&response_type=code&redirect_uri=https%3A%2F%2Ff5c97a57-5945-4b06-bf77-d78233900787-00-1fs5de46gro5g.sisko.replit.dev%2F&scope=identify+gdm.join+guilds.join+email`,

}
